package com.research;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiResearchSummariserApplicationTests {

	@Test
	void contextLoads() {
	}

}
